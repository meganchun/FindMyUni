package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.*;

public class Controller {
	
	private SurveyGUIFrame surveyGUI;
	private ResultsGUIFrame resultsGUI;
	
	// calls the createSurvey method
	public Controller() {
		createSurvey();
	}
	
	// creates the survey frame and adds the necessary action listeners
	public void createSurvey() {
		surveyGUI = new SurveyGUIFrame();
		ActionListenersSurvey();
	}
	
	// the action listeners for the survey
	public void ActionListenersSurvey() {
		
		// submit button will close the survey frame and call the create results method
    	surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getSubmitButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				surveyGUI.dispose();
				createResults();
			}
    	});
	}
	
	// method used to create the results with the necessary action listeners
	public void createResults() {
		resultsGUI = new ResultsGUIFrame(this);
		ActionListenersResults();
	}
	
	// set and get methods
	public void ActionListenersResults() {
		
	}

	public SurveyGUIFrame getSurveyGUI() {
		return surveyGUI;
	}

	public void setSurveyGUI(SurveyGUIFrame surveyGUI) {
		this.surveyGUI = surveyGUI;
	}

	public ResultsGUIFrame getResultsGUI() {
		return resultsGUI;
	}

	public void setResultsGUI(ResultsGUIFrame resultsGUI) {
		
	}
}
