package View;

import javax.swing.*;
import java.awt.*;

import Controller.*;
import Model.*;

public class ResultsGUIPanel extends JPanel {
	
	RecommendedProgramsGUI recommendedPrograms;
	
	FontClass fonts;
	
	ResultsGUIFrame resultsFrame;
	
	public ResultsGUIPanel(ResultsGUIFrame resultsFrame) {
		
		this.resultsFrame = resultsFrame;
		
		setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
		this.setBackground(new Color(243, 244, 245));
		
		add(Box.createRigidArea(new Dimension(0, 20)));
		
		// may want to make this area fading images
		// https://stackoverflow.com/questions/20346661/java-fade-in-and-out-of-images
		JLabel image = new JLabel(new ImageIcon("Images/randomImage.png"));
		image.setSize(950,150);
		image.setBackground(new Color(243, 244, 245));
		image.setAlignmentX(Component.CENTER_ALIGNMENT);
		add(image);
		
		add(Box.createRigidArea(new Dimension(0, 40)));
		
//		image.setBounds(25,15,950,150);
		
//		JPanel topResultsPanel = new JPanel();
//		topResultsPanel.setSize(1000,1000);
////		topResultsPanel.setBounds(25,200,1000,1000);
		
		JLabel top = new JLabel("Recommended Programs: ");
		top.setFont(FontClass.semibold30);
		top.setSize(1015,30);
		top.setHorizontalAlignment(SwingConstants.LEFT);
		add(top);
		
		recommendedPrograms = new RecommendedProgramsGUI(this);
		add(recommendedPrograms);
		
		this.setSize(1015,5000);
		this.setVisible(true);

	}

	public ResultsGUIFrame getResultsFrame() {
		return resultsFrame;
	}

	public void setResultsFrame(ResultsGUIFrame resultsFrame) {
		this.resultsFrame = resultsFrame;
	}

}
