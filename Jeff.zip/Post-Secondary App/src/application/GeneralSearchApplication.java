package application;

import controller.GeneralSearchController;

public class GeneralSearchApplication {

	public static void main(String[] args) {
	
		GeneralSearchController program = new GeneralSearchController();

	}

}
