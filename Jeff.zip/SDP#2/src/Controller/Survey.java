package Controller;
import View.*;
import Model.*;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JComboBox;

import Model.*;

public class Survey {

	Controller controller;
	Results results;
	SurveyGUIFrame surveyGUI;
	ResultsGUIFrame resultsGUI;
	
	double weightedAverage;
	
	public Survey(Controller controller) {
		this.controller = controller;
		results = new Results(this);
//		double str1 = Double.parseDouble(surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks()[1].getGr11MarkPercent().getText());
		
	}
	
	public void createSurvey() {
		surveyGUI = new SurveyGUIFrame();
		ActionListenersSurvey();
	}
	
	public void ActionListenersSurvey() {
		
    	surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getSubmitButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getSurveyGUI().dispose();
//				calculateBestPrograms();
				getResults().createResults();
			}
    	});
	}
	
	public Controller getController() {
		return controller;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}

	public Results getResults() {
		return results;
	}

	public void setResults(Results results) {
		this.results = results;
	}

	public SurveyGUIFrame getSurveyGUI() {
		return surveyGUI;
	}

	public void setSurveyGUI(SurveyGUIFrame surveyGUI) {
		this.surveyGUI = surveyGUI;
	}

	public ResultsGUIFrame getResultsGUI() {
		return resultsGUI;
	}

	public void setResultsGUI(ResultsGUIFrame resultsGUI) {
		this.resultsGUI = resultsGUI;
	}

}
