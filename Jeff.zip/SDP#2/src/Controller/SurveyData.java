package Controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import Model.FileReader;
import Model.Program;
import Model.ProgramPanel;
import View.SurveyGUIFrame;

public class SurveyData {

	SurveyGUIFrame surveyGUI;
	
	public FileReader file;
	
//	ArrayList<String> programs1 = new ArrayList<String>();
	
	String preferredProgram;
	double weightedAverage;
	
	public SurveyData() {
		
	}
	
//	// finds what the preferred program is from the accounts txt
//	public String getPreferredProgram() {
//		try {
//			Scanner userInfo = new Scanner(new File("data/accounts"));
//			userInfo.useDelimiter(",");										
//			// Iterate through all programs 
//			String username = userInfo.next();
//			int password = userInfo.nextInt();
//			String firstname = userInfo.next();
//			String lastname = userInfo.next();
//			String email = userInfo.next();
//			int addressNumber = userInfo.nextInt();
//			String street = userInfo.next();
//			String city = userInfo.next();
//			String postalcode = userInfo.next();
//			preferredProgram = userInfo.next();
//			
//		} catch (FileNotFoundException e) { // for errors or if there is no input
//			System.out.println("File Error");
//		}
//		System.out.println("preferred program: " + preferredProgram);
//		return preferredProgram;
//	}
//
//	// finds how many lines are in the txt file of the preferred program
//	// https://mkyong.com/java/how-to-get-the-total-number-of-lines-of-a-file-in-java/
//	public static long countLineJava8(String filename) {
//	      Path path = Paths.get(filename);
//	      long lines = 0;
//	      try {
//	          // much slower, this task better with sequence access
//	          //lines = Files.lines(path).parallel().count();
//	          lines = Files.lines(path).count();
//	      } catch (IOException e) {
//	          e.printStackTrace();
//	      }
//	      return lines;
//	  }
//	
//	// finds the average of both gr11, and gr12 marks, and find he average of those 2 marks (weighs the gr12 marks
//	// because they're more important)
//	public double getWeightedAverage() {
//		int totalGr11Courses = 0;
//		double totalGr11Marks = 0;
//		
//		int totalGr12Courses = 0;
//		double totalGr12Marks = 0;
//		
//		for (int i = 0; i < surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks().length; i++) {	
//			String currentGr11Course = (String) surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks()[i].getCourseDropdown().getSelectedItem();		
//			if (currentGr11Course != null) {
////				programs1.add(currentGr11Course);
//				totalGr11Courses++;
//			}		
//			
//			String currentGr11Mark = surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks()[i].getGr11MarkPercent().getText();
//			if (!currentGr11Mark.isEmpty()) {
//				Double calculation = Double.valueOf(currentGr11Mark);
//				totalGr11Marks+=calculation;
//			}
//		}
//		
//		for (int i = 0; i < surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr12Marks().length; i++) {	
//			String currentGr12Course = (String) surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr12Marks()[i].getCourseDropdown().getSelectedItem();
//			
//			if (currentGr12Course != null) {
//				totalGr12Courses++;
//			}		
//			
//			String currentGr12Mark = surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getGr12Marks()[i].getGr11MarkPercent().getText();
//			
//			if (!currentGr12Mark.isEmpty()) {
//				Double calculation = Double.valueOf(currentGr12Mark);
//				totalGr12Marks+=calculation;
//			}
//		}
//		
//		double gr11Avg = totalGr11Marks / totalGr11Courses;
//		System.out.println("Avg Gr11: " + gr11Avg);
//		
//		double gr12Avg = totalGr12Marks / totalGr12Courses;
//		System.out.println("Avg Gr12: " + gr12Avg);
//		
//		weightedAverage = (gr11Avg*0.3 + gr12Avg*0.7);
//		
//		System.out.println("Weighted Avg: " + weightedAverage);
//		return weightedAverage;
//	}

	public SurveyGUIFrame getSurveyGUI() {
		return surveyGUI;
	}

	public void setSurveyGUI(SurveyGUIFrame surveyGUI) {
		this.surveyGUI = surveyGUI;
	}
	
}
