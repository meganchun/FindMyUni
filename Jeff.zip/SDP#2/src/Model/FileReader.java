// 100% jeff

package Model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileReader {
	
	//This array list will hold all the programs
	ArrayList<Program> programArraylist = new ArrayList<>();
//	
//	ArrayList<Program> compSciProgramArrayList = new ArrayList<>();
//	
//	ArrayList<Program> engineeringProgramArrayList = new ArrayList<>();
//	
//	ArrayList<Program> mathProgramArrayList = new ArrayList<>();
//	
//	ArrayList<Program> scienceProgramArrayList = new ArrayList<>();

	public FileReader() {
			
		try {

			Scanner programs = new Scanner(new File("data/allPrograms"));
			programs.useDelimiter("\\*|\r\n");										
			// Iterate through all programs 
			for (int i = 0; i < 305; i++) {
				int programNum = programs.nextInt();
				String programName = programs.next();
				String universityName = programs.next();
				String gradeRange = programs.next();
				String degree = programs.next();
				String address = programs.next();
				String programLink = programs.next();
				String prerequisites = programs.next();
				String[] courses = convList(prerequisites);
				
				// Add the created programs to the program array
				programArraylist.add(new Program(programNum, programName, universityName, gradeRange, degree, address, programLink, courses));
			}
	
		} catch (FileNotFoundException e) { // for errors or if there is no input
			System.out.println("File Error");
		}	
//		
//		try {
//
//			Scanner compSciPrograms = new Scanner(new File("data/compSciPrograms"));
//			compSciPrograms.useDelimiter("\\*|\r\n");										
//			// Iterate through all programs 
//			for (int i = 0; i < 64; i++) {
//				int programNum = compSciPrograms.nextInt();
//				String programName = compSciPrograms.next();
//				String universityName = compSciPrograms.next();
//				String gradeRange = compSciPrograms.next();
//				String degree = compSciPrograms.next();
//				String address = compSciPrograms.next();
//				String programLink = compSciPrograms.next();
//				String prerequisites = compSciPrograms.next();
//				String[] courses = convList(prerequisites);
//				
//				// Add the created programs to the program array
//				compSciProgramArrayList.add(new Program(programNum, programName, universityName, gradeRange, degree, address, programLink, courses));
//			}
//	
//		} catch (FileNotFoundException e) { // for errors or if there is no input
//			System.out.println("File Error");
//		}	
//		
//		try {
//
//			Scanner engineeringPrograms = new Scanner(new File("data/engPrograms"));
//			engineeringPrograms.useDelimiter("\\*|\r\n");										
//			// Iterate through all programs 
//			for (int i = 0; i < 126; i++) {
//				int programNum = engineeringPrograms.nextInt();
//				String programName = engineeringPrograms.next();
//				String universityName = engineeringPrograms.next();
//				String gradeRange = engineeringPrograms.next();
//				String degree = engineeringPrograms.next();
//				String address = engineeringPrograms.next();
//				String programLink = engineeringPrograms.next();
//				String prerequisites = engineeringPrograms.next();
//				String[] courses = convList(prerequisites);
//				
//				// Add the created programs to the program array
//				engineeringProgramArrayList.add(new Program(programNum, programName, universityName, gradeRange, degree, address, programLink, courses));
//			}
//	
//		} catch (FileNotFoundException e) { // for errors or if there is no input
//			System.out.println("File Error");
//		}
//		
//		try {
//
//			Scanner mathPrograms = new Scanner(new File("data/mathPrograms"));
//			mathPrograms.useDelimiter("\\*|\r\n");										
//			// Iterate through all programs 
//			for (int i = 0; i < 22; i++) {
//				int programNum = mathPrograms.nextInt();
//				String programName = mathPrograms.next();
//				String universityName = mathPrograms.next();
//				String gradeRange = mathPrograms.next();
//				String degree = mathPrograms.next();
//				String address = mathPrograms.next();
//				String programLink = mathPrograms.next();
//				String prerequisites = mathPrograms.next();
//				String[] courses = convList(prerequisites);
//				
//				// Add the created programs to the program array
//				mathProgramArrayList.add(new Program(programNum, programName, universityName, gradeRange, degree, address, programLink, courses));
//			}
//	
//		} catch (FileNotFoundException e) { // for errors or if there is no input
//			System.out.println("File Error");
//		}
//		
//		try {
//
//			Scanner sciencePrograms = new Scanner(new File("data/sciencePrograms"));
//			sciencePrograms.useDelimiter("\\*|\r\n");										
//			// Iterate through all programs 
//			for (int i = 0; i < 200; i++) {
//				int programNum = sciencePrograms.nextInt();
//				String programName = sciencePrograms.next();
//				String universityName = sciencePrograms.next();
//				String gradeRange = sciencePrograms.next();
//				String degree = sciencePrograms.next();
//				String address = sciencePrograms.next();
//				String programLink = sciencePrograms.next();
//				String prerequisites = sciencePrograms.next();
//				String[] courses = convList(prerequisites);
//				
//				// Add the created programs to the program array
//				scienceProgramArrayList.add(new Program(programNum, programName, universityName, gradeRange, degree, address, programLink, courses));
//			}
//	
//		} catch (FileNotFoundException e) { // for errors or if there is no input
//			System.out.println("File Error");
//		}
//		
	}
	
	public String[] convList(String prerequisites) {			
		String[] programArray = prerequisites.split("\\|",-2);
		return programArray;
	}

	public ArrayList<Program> getProgramArray() {
		return programArraylist;
	}
//	
//	public ArrayList<Program> getCompSciProgramArray() {
//		return compSciProgramArrayList;
//	}
//
//	public ArrayList<Program> getEngineeringProgramArray() {
//		return engineeringProgramArrayList;
//	}
//
//	public ArrayList<Program> getMathProgramArray() {
//		return mathProgramArrayList;
//	}
//
//	public ArrayList<Program> getScienceProgramArray() {
//		return scienceProgramArrayList;
//	}
}
