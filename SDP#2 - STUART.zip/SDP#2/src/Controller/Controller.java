package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.ResultsGUIFrame;
import View.SurveyGUIFrame;

public class Controller {
	
	SurveyGUIFrame surveyGUI;
	ResultsGUIFrame resultsGUI;
	
	public Controller() {
		createSurvey();
	}
	
	public void createSurvey() {
		surveyGUI = new SurveyGUIFrame();
		ActionListenersSurvey();
	}
	
	public void ActionListenersSurvey() {
		
    	surveyGUI.getSurveyGUIPanel().getMarksGUIsPanel().getSubmitButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				surveyGUI.dispose();
//				calculateBestPrograms();
				createResults();
			}
    	});
	}
	
	public void createResults() {
		resultsGUI = new ResultsGUIFrame();
		ActionListenersResults();
	}
	
	public void ActionListenersResults() {
		
	}
	
}
