package View;

import Controller.*;
import Model.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class ResultsProgramPanelGUI extends JPanel {
	
	SurveyGUIPanel surveyPanel;
	
	ArrayList<Program> preferredProgramsArrayList = new ArrayList<>();
	
	ProgramPanel[] programs;
	
	SurveyGUIFrame surveyGUI;
	
	FileReader file;
	
	String preferredProgram;
	double weightedAverage;
	
	public ResultsProgramPanelGUI() {
		
		suggestedPrograms();
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		programs = new ProgramPanel[preferredProgramsArrayList.size()];
		
		int programNum = 0;
		for(int i = 0; i < preferredProgramsArrayList.size(); i++ ) {			
			Double reqGrade = Double.valueOf(preferredProgramsArrayList.get(i).getGradeRequirement());
			programNum++;
			// if the required grade of a program is less or equal to the user's average
			// and if the program falls under the user's preferred field
			// it will find the best out of those options / or maybe just take them all
			// and return the programNum to be used in the gui
			if (getWeightedAverage() >= reqGrade) {
				ProgramPanel currentProgram = programs[i];
				
				currentProgram  = new ProgramPanel(preferredProgramsArrayList.get(i).getName(),
						preferredProgramsArrayList.get(i).getUniversity(),
						false, 
						preferredProgramsArrayList.get(i),
						preferredProgramsArrayList.get(i).getGradeRequirement());
				
				currentProgram.getProgramBackground().add(currentProgram.getProgramName());
				currentProgram.getProgramBackground().add(currentProgram.getUniversityName());
				currentProgram.getProgramBackground().add(currentProgram.getFavouriteButton());
				
				currentProgram.getFavouriteButton().setFocusPainted(false);
				currentProgram.getFavouriteButton().setContentAreaFilled(false);
				currentProgram.getFavouriteButton().setBorderPainted(false);
				
				currentProgram.getProgramName().setBorderPainted(false);
				currentProgram.getProgramName().setContentAreaFilled(false);
				currentProgram.getProgramName().setFocusPainted(false);
				currentProgram.getProgramName().setHorizontalAlignment(SwingConstants.LEFT);
				
				currentProgram.getUniversityName().setBorderPainted(false);
				currentProgram.getUniversityName().setContentAreaFilled(false);
				currentProgram.getUniversityName().setFocusPainted(false);
				currentProgram.getUniversityName().setHorizontalAlignment(SwingConstants.LEFT);

				programs[i] = currentProgram;
				this.add(currentProgram);	
			}
			System.out.println("total # of programs:" + programNum);
			
		}
		this.setSize(950,260);
		this.setVisible(true);
	}

	public void suggestedPrograms() {
		
		try {
			Scanner program = new Scanner(new File("data/" + getPreferredProgram()));
			program.useDelimiter("\\*|\r\n");										
			// Iterate through all programs 
			for (int i = 0; i < countLineJava8("data/" + getPreferredProgram()); i++) {
				int programNum = program.nextInt();
				String programName = program.next();
				String universityName = program.next();
				String gradeRange = program.next();
				String degree = program.next();
				String address = program.next();
				String programLink = program.next();
				String prerequisites = program.next();
				String[] courses = convList(prerequisites);
				
				System.out.println(programNum+programName+universityName+gradeRange+degree+address+programLink+prerequisites);
				// Add the created programs to the program array
				preferredProgramsArrayList.add(new Program(programNum, programName, universityName, gradeRange, degree, address, programLink, courses));
			}
	
		} catch (FileNotFoundException e) { // for errors or if there is no input
			System.out.println("suggested File Error");
		}	
	}
	
	public String[] convList(String prerequisites) {			
		String[] programArray = prerequisites.split("\\|",-2);
		return programArray;
	}
	
	// finds what the preferred program is from the accounts txt
	public String getPreferredProgram() {
		try {
			Scanner userInfo = new Scanner(new File("data/accounts"));
			userInfo.useDelimiter(",");										
			// Iterate through all programs 
			String username = userInfo.next();
			int password = userInfo.nextInt();
			String firstname = userInfo.next();
			String lastname = userInfo.next();
			String email = userInfo.next();
			int addressNumber = userInfo.nextInt();
			String street = userInfo.next();
			String city = userInfo.next();
			String postalcode = userInfo.next();
			preferredProgram = userInfo.next();
			
		} catch (FileNotFoundException e) { // for errors or if there is no input
			System.out.println("File Error");
		}
		System.out.println("preferred program: " + preferredProgram);
		return preferredProgram;
	}

	// finds how many lines are in the txt file of the preferred program
	// https://mkyong.com/java/how-to-get-the-total-number-of-lines-of-a-file-in-java/
	public static long countLineJava8(String filename) {
	      Path path = Paths.get(filename);
	      long lines = 0;
	      try {
	          // much slower, this task better with sequence access
	          //lines = Files.lines(path).parallel().count();
	          lines = Files.lines(path).count();
	      } catch (IOException e) {
	          e.printStackTrace();
	      }
	      return lines;
	  }
	
	// finds the average of both gr11, and gr12 marks, and find he average of those 2 marks (weighs the gr12 marks
	// because they're more important)
	public double getWeightedAverage() {
		int totalGr11Courses = 0;
		double totalGr11Marks = 0;
		
		int totalGr12Courses = 0;
		double totalGr12Marks = 0;
		
		for (int i = 0; i < getSurveyGUI().getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks().length; i++) {
			String currentGr11Course = (String) getSurveyGUI().getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks()[i].getCourseDropdown().getSelectedItem();		
//			System.out.println("slay" + currentGr11Course);
			if (currentGr11Course != null) {
//				programs1.add(currentGr11Course);
				totalGr11Courses++;
			}		
			
			String currentGr11Mark = getSurveyGUI().getSurveyGUIPanel().getMarksGUIsPanel().getGr11Marks()[i].getGr11MarkPercent().getText();
//			System.out.println("slay" + currentGr11Mark);
			if (!currentGr11Mark.isEmpty()) {
				Double calculation = Double.valueOf(currentGr11Mark);
				totalGr11Marks+=calculation;
			}
		}
		
		for (int i = 0; i < getSurveyGUI().getSurveyGUIPanel().getMarksGUIsPanel().getGr12Marks().length; i++) {	
			String currentGr12Course = (String) getSurveyGUI().getSurveyGUIPanel().getMarksGUIsPanel().getGr12Marks()[i].getCourseDropdown().getSelectedItem();
			
			if (currentGr12Course != null) {
				totalGr12Courses++;
			}		
			
			String currentGr12Mark = getSurveyGUI().getSurveyGUIPanel().getMarksGUIsPanel().getGr12Marks()[i].getGr11MarkPercent().getText();
			
			if (!currentGr12Mark.isEmpty()) {
				Double calculation = Double.valueOf(currentGr12Mark);
				totalGr12Marks+=calculation;
			}
		}
		
		double gr11Avg = totalGr11Marks / totalGr11Courses;
		System.out.println("Avg Gr11: " + gr11Avg);
		
		double gr12Avg = totalGr12Marks / totalGr12Courses;
		System.out.println("Avg Gr12: " + gr12Avg);
		
		weightedAverage = (gr11Avg*0.3 + gr12Avg*0.7);
		
		System.out.println("Weighted Avg: " + weightedAverage);
		return weightedAverage;
	}

	public ArrayList<Program> getPreferredProgramsArrayList() {
		return preferredProgramsArrayList;
	}

	public void setPreferredProgramsArrayList(ArrayList<Program> preferredProgramsArrayList) {
		this.preferredProgramsArrayList = preferredProgramsArrayList;
	}

	public ProgramPanel[] getPrograms() {
		return programs;
	}

	public void setPrograms(ProgramPanel[] programs) {
		this.programs = programs;
	}

	public SurveyGUIFrame getSurveyGUI() {
		return surveyGUI;
	}

	public void setSurveyGUI(SurveyGUIFrame surveyGUI) {
		this.surveyGUI = surveyGUI;
	}

}
