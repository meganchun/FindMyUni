package View;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class test extends JFrame {

	JCheckBox e = new JCheckBox("hehehe");
	
	public test() {
		
		JPanel he = new JPanel();
		he.setBounds(100,100,1000,500);
		
		
		e.setBounds(200,200,200,20);
		he.add(e);
		
		add(he);
		
		this.setLayout(null);
		this.setSize(1000,500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		
		new test();
		
	}

}
